import 'package:flutter/material.dart';

void main() => runApp(const TraderRApp());

const gold = Color(0xFFD6AD55);
const bg = Color(0xFF090A0D);
const panel = Color(0xFF15171D);

class TraderRApp extends StatelessWidget {
  const TraderRApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TRADER R AI',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.dark,
          surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: CardTheme(
          color: panel,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF292C34)),
          ),
        ),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [
    HomePage(),
    AnalyzerPage(),
    AcademyPage(),
    JournalPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111319),
        indicatorColor: gold.withOpacity(.18),
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.candlestick_chart), label: 'Analyzer'),
          NavigationDestination(icon: Icon(Icons.school_outlined), label: 'Academy'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Journal'),
        ],
      ),
    );
  }
}

class PageTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const PageTitle(this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: .4)),
      const SizedBox(height: 5),
      Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 13)),
    ]),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      const PageTitle('TRADER R AI', 'SMART MARKET ANALYSIS • LEARNING • DISCIPLINE'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF302719), Color(0xFF17130E)]),
            border: Border.all(color: gold.withOpacity(.45)),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('YOUR AI TRADING MENTOR', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1)),
            SizedBox(height: 10),
            Text('Analyze first. Decide later.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            SizedBox(height: 8),
            Text('Learn to read market structure, liquidity, price action and risk — without profit guarantees.',
              style: TextStyle(color: Colors.white70, height: 1.4)),
          ]),
        ),
      ),
      const SectionHeading('Analysis tools'),
      GridView.count(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.55,
        children: const [
          ToolTile(Icons.candlestick_chart, 'AI Chart Analyzer', 'Chart review workflow'),
          ToolTile(Icons.account_tree_outlined, 'Market Structure', 'HH • HL • BOS • CHOCH'),
          ToolTile(Icons.waves_outlined, 'Liquidity Scanner', 'Potential liquidity zones'),
          ToolTile(Icons.newspaper_outlined, 'News Center', 'USD • Gold • Macro events'),
          ToolTile(Icons.school_outlined, 'Trading Academy', 'Lessons and case studies'),
          ToolTile(Icons.book_outlined, 'Trading Journal', 'Record decisions and errors'),
        ],
      ),
      const SectionHeading('Core principles'),
      const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Column(children: [
          PrincipleTile('01', 'Evidence before opinion', 'No market conclusion without visible supporting evidence.'),
          PrincipleTile('02', 'Risk before reward', 'Understand uncertainty and risk before considering any setup.'),
          PrincipleTile('03', 'No-trade is a decision', 'Incomplete analysis means wait, learn, or stay out.'),
        ]),
      ),
    ]);
  }
}

class SectionHeading extends StatelessWidget {
  final String text;
  const SectionHeading(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
    child: Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
  );
}

class ToolTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const ToolTile(this.icon, this.title, this.subtitle, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: gold, size: 25),
        const SizedBox(height: 9),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 10)),
      ]),
    ),
  );
}

class PrincipleTile extends StatelessWidget {
  final String number, title, description;
  const PrincipleTile(this.number, this.title, this.description, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Text(number, style: const TextStyle(color: gold, fontWeight: FontWeight.w900)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      subtitle: Text(description, style: const TextStyle(color: Colors.white60, fontSize: 12)),
    ),
  );
}

class AnalyzerPage extends StatefulWidget {
  const AnalyzerPage({super.key});
  @override
  State<AnalyzerPage> createState() => _AnalyzerPageState();
}

class _AnalyzerPageState extends State<AnalyzerPage> {
  String market = 'Gold (XAU/USD)';
  String timeframe = '15m';
  bool showExample = false;

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.only(bottom: 28), children: [
      const PageTitle('AI Chart Analyzer', 'Educational chart review — not trade signals'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Market', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: market,
              items: const ['Gold (XAU/USD)', 'Forex', 'Crypto', 'Stocks'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => setState(() => market = v ?? market),
            ),
            const SizedBox(height: 14),
            const Text('Timeframe', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: ['1m','5m','15m','1h','4h','1D'].map((e) =>
              ChoiceChip(label: Text(e), selected: timeframe == e, onSelected: (_) => setState(() => timeframe = e))
            ).toList()),
            const SizedBox(height: 18),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white12)),
              child: const Column(children: [
                Icon(Icons.add_photo_alternate_outlined, color: gold, size: 38),
                SizedBox(height: 10),
                Text('Chart image upload', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 5),
                Text('Image upload and AI vision connection will be added in the next build.',
                  textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
              ]),
            ),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
              onPressed: () => setState(() => showExample = !showExample),
              child: Text(showExample ? 'Hide sample analysis' : 'View sample analysis'),
            )),
          ]),
        )),
      ),
      if (showExample) const SampleAnalysis(),
      const Padding(
        padding: EdgeInsets.all(18),
        child: Text('Important: This starter screen does not fetch live prices or generate real AI analysis yet. Never treat the sample as a real market assessment.',
          style: TextStyle(color: Colors.orangeAccent, fontSize: 12, height: 1.4)),
      ),
    ]);
  }
}

class SampleAnalysis extends StatelessWidget {
  const SampleAnalysis({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: Card(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('SAMPLE ANALYSIS', style: TextStyle(color: gold, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        ResultRow('Trend', 'Not assessed'),
        ResultRow('Market structure', 'Needs chart evidence'),
        ResultRow('Liquidity', 'Not confirmed'),
        ResultRow('Support / Resistance', 'Needs chart levels'),
        Divider(height: 24),
        Text('AI conclusion', style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text('Upload a clear chart with symbol and timeframe before drawing conclusions. Missing evidence means analysis is incomplete.',
          style: TextStyle(color: Colors.white70, height: 1.4)),
      ]),
    )),
  );
}

class ResultRow extends StatelessWidget {
  final String label, value;
  const ResultRow(this.label, this.value, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 13)),
      Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
    ]),
  );
}

class AcademyPage extends StatelessWidget {
  const AcademyPage({super.key});
  static const lessons = [
    ('01', 'Market Structure', 'HH, HL, LH, LL, BOS and CHOCH'),
    ('02', 'Support & Resistance', 'Zones, reactions and invalidation'),
    ('03', 'Liquidity Concepts', 'Buy-side, sell-side and sweeps'),
    ('04', 'Breakout & Fakeout', 'Acceptance, rejection and retests'),
    ('05', 'Price Action', 'Candles, momentum and confirmation'),
    ('06', 'Risk & Psychology', 'Discipline, journaling and uncertainty'),
  ];
  @override
  Widget build(BuildContext context) => ListView(children: [
    const PageTitle('Trading Academy', 'Advanced learning path • বাংলা + English'),
    ...lessons.map((l) => Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: gold.withOpacity(.16), child: Text(l.$1, style: const TextStyle(color: gold))),
        title: Text(l.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(l.$3, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        trailing: const Icon(Icons.chevron_right, color: gold),
      ),
    )),
    const Padding(padding: EdgeInsets.all(18), child: Text('Lessons are educational. They do not promise a winning strategy or fixed win rate.', style: TextStyle(color: Colors.white54, fontSize: 12))),
  ]);
}

class JournalPage extends StatelessWidget {
  const JournalPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: const [
    PageTitle('Trading Journal', 'Track practice, decisions and learning'),
    Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: Card(child: Padding(
        padding: EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.edit_note, color: gold, size: 34),
          SizedBox(height: 12),
          Text('Your journal is ready for the next build', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          SizedBox(height: 8),
          Text('Planned fields: date, market, timeframe, setup, evidence, decision, outcome, emotional state and lesson learned.',
            style: TextStyle(color: Colors.white60, height: 1.5)),
        ]),
      )),
    ),
  ]);
}
